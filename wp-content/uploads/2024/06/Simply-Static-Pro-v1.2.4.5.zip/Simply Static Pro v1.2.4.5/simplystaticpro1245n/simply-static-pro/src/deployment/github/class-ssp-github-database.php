<?php

namespace simply_static_pro;

use Github\Client;
use Github\Exception\ValidationFailedException;
use Github\Exception\RuntimeException;
use Github\Exception\ApiLimitExceedException;
use Simply_Static\Util;

/**
 * Class to handle GitHub repositories.
 */
class Github_Database {
	/**
	 * Contains instance or null
	 *
	 * @var object|null
	 */
	private static $instance = null;

	/**
	 * Contains new GitHub client.
	 *
	 * @var object
	 */
	private $client;

	/**
	 * Contains the username.
	 *
	 * @var string
	 */
	private $user;

	/**
	 * Contains the name of the repository.
	 *
	 * @var string
	 */
	private $repository;

	/**
	 * Contains the name of the branch.
	 *
	 * @var string
	 */
	private $branch;

	/**
	 * Contains the committer with name and email as array.
	 *
	 * @var array
	 */
	private $committer;

	/**
	 * Returns instance of Github_Database.
	 *
	 * @return object
	 */
	public static function get_instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor for file class.
	 */
	public function __construct() {
		$options = get_option( 'simply-static' );
		$client  = new Client();

		// Authenticate.
		$client->authenticate( $options['github-personal-access-token'], $client::AUTH_ACCESS_TOKEN );

		$this->client     = $client;
		$this->user       = $options['github-user'];
		$this->repository = $options['github-repository'];
		$this->branch     = $options['github-branch'];
		$this->committer  = array( 'name' => $options['github-user'], 'email' => $options['github-email'] );
	}

	/**
	 * Create blob from file input.
	 *
	 * @param string $file_path given file path.
	 * @param string $relative_path given relative path.
	 * @param string $content given file content.
	 *
	 * @return array|false
	 */
	public function create_blob( string $file_path, string $relative_path, string $content ) {
		// Windows support for path.
		if ( strpos( $relative_path, '\\' ) !== false || strpos( $relative_path, '\\' ) !== false ) {
			$relative_path = str_replace( '\\', '/', $relative_path );
		}

		// Setup the content.
		$args = array(
			'content'  => base64_encode( $content ),
			'encoding' => 'base64'
		);

		// if it's a UTF-8 compatible mime type, change the args.
		$file_info       = pathinfo( $file_path );
		$utf8_mime_types = apply_filters( 'ssp_utf8_mime_types', array(
			'shtml',
			'xhtml',
			'html',
			'xml',
			'json',
			'csv',
			'css',
			'scss',
			'js',
			'txt',
			'pdf'
		) );

		if ( in_array( $file_info['extension'], $utf8_mime_types, true ) ) {
			$args = array(
				'content'  => $content,
				'encoding' => 'utf-8'
			);
		}

		try {
			$response = $this->client->api( 'gitData' )->blobs()->create( $this->user, $this->repository, $args );

			// Add required data to blob.
			return array(
				'path' => $relative_path,
				'mode' => '100644',
				'type' => 'blob',
				'sha'  => $response['sha']
			);
		} catch ( ValidationFailedException|RuntimeException|ApiLimitExceedException $e ) {
			Util::debug_log( $e->getMessage() );
			return false;
		}
	}

	/**
	 * Create new tree with blobs.
	 *
	 * @param array $blobs an array of blobs.
	 *
	 * @return array|false
	 */
	public function create_tree( array $blobs ) {
		// Get the base tree.
		$base_tree = $this->client->api( 'gitData' )->trees()->show( $this->user, $this->repository, $this->branch );

		// Create tree with blobs.
		$tree_data = array(
			'base_tree' => $base_tree['sha'],
			'tree'      => $blobs
		);

		try {
			$tree = $this->client->api( 'gitData' )->trees()->create( $this->user, $this->repository, $tree_data );

			return array(
				'tree-sha'      => $tree['sha'],
				'base-tree-sha' => $base_tree['sha']
			);

		} catch ( ValidationFailedException|RuntimeException|ApiLimitExceedException $e ) {
			Util::debug_log( $e->getMessage() );

			return false;
		}
	}

	/**
	 * Commit changes to GitHub.
	 *
	 * @param string $message given commit mesage.
	 * @param array $tree_data given tree SHAs.
	 *
	 * @return false|void
	 */
	public function commit( string $message, array $tree_data ) {
		$commit_data = array(
			'message' => $message,
			'tree'    => $tree_data['tree-sha'],
			'parents' => array( $tree_data['base-tree-sha'] )
		);

		try {
			$commit = $this->client->api( 'gitData' )->commits()->create( $this->user, $this->repository, $commit_data );
		} catch ( ValidationFailedException|RuntimeException|ApiLimitExceedException $e ) {
			Util::debug_log( $e->getMessage() );

			return false;
		}

		// Now update the reference.
		$ref_data = array(
			'sha'   => $commit['sha'],
			'force' => true
		);

		try {
			$this->client->api( 'gitData' )->references()->update( $this->user, $this->repository, 'heads/' . $this->branch, $ref_data );
		} catch ( ValidationFailedException|RuntimeException|ApiLimitExceedException $e ) {
			Util::debug_log( $e->getMessage() );

			return false;
		}
	}
}
