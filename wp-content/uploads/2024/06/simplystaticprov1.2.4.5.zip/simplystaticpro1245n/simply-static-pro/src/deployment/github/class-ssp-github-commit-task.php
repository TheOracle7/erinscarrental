<?php

namespace simply_static_pro;

use Simply_Static;

/**
 * Class which handles GitHub commits.
 */
class Github_Commit_Task extends Simply_Static\Task {
	/**
	 * The task name.
	 *
	 * @var string
	 */
	protected static $task_name = 'github_commit';

	/**
	 * Constructor
	 */
	public function __construct() {
		parent::__construct();

		$options          = Simply_Static\Options::instance();
		$this->options    = $options;
		$this->temp_dir   = $options->get_archive_dir();
		$this->start_time = $options->get( 'archive_start_time' );
	}

	/**
	 * Perform action to run on commit task.
	 *
	 * @return bool
	 */
	public function perform() {
		$options = get_option( 'simply-static' );
		$message = __( 'Starts to transfer pages/files to GitHub', 'simply-static-pro' );
		$this->save_status_message( $message );

		// Maybe clear repository before adding files?
		if ( 'yes' === $options['github-repository-reset'] ) {
			// Check that it's a full static export.
			$use_single = get_option( 'simply-static-use-single' );
			$use_build  = get_option( 'simply-static-use-build' );

			if ( empty( $use_build ) && empty( $use_single ) ) {
				// Get repository class instance.
				$repository = Github_Repository::get_instance();

				// Store repository configuration.
				$current_repo = $options['github-repository'];

				// Delete and recreate repository.
				$repository->delete_repository();

				// Update settings again.
				$options['github-repository'] = $current_repo;

				update_option( 'simply-static', $options );

				// Now recreate repository.
				$repository->add_repository();
			}
		}

		// Upload directory.
		$iterator = new \RecursiveIteratorIterator( new \RecursiveDirectoryIterator( $this->temp_dir, \RecursiveDirectoryIterator::SKIP_DOTS ) );
		$counter  = 0;

		// Prepare GitHub API.
		$database = Github_Database::get_instance();
		$blobs    = array();

		// Prepare WP Filesystem.
		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once( ABSPATH . 'wp-admin/includes/file.php' );
		}

		if ( is_null( $wp_filesystem ) ) {
			WP_Filesystem();
		}

		// Maybe throttle request.
		$throttle_request = apply_filters( 'ssp_throttle_github_request', true );

		// Check if cron available.
		$is_cron = false;

		if ( 'on' === $options['use_cron'] && ! defined( 'DISABLE_WP_CRON' ) || 'on' === $options['use_cron'] && defined( 'SS_CRON' ) ) {
			$is_cron = true;
		}
		
		if ( ! $is_cron ) {
			$throttle_request = apply_filters( 'ssp_throttle_github_request', false );
		}

		foreach ( $iterator as $file_path => $file_object ) {
			if ( ! realpath( $file_path ) ) {
				continue;
			}

			$content       = $wp_filesystem->get_contents( $file_path );
			$relative_path = str_replace( $this->temp_dir, '', $file_path );

			// Prepare file for commit.
			$blob = $database->create_blob( $file_path, $relative_path, $content );

			// Maybe throttle request.
			if ( $throttle_request ) {
				sleep( 1 );
			}

			if ( false !== $blob ) {
				$blobs[] = $blob;
			} else {
				continue;
			}
			$counter ++;
		}

		// Create new tree with blobs.
		$tree_data = $database->create_tree( $blobs );

		if ( false !== $tree_data ) {
			// Now create a new commit with the tree.
			$commit_message = apply_filters( 'ssp_github_commit_message', 'Updated/Added ' . $this->options->get( 'archive_name' ) );

			$database->commit( $commit_message, $tree_data );
		}

		$message = sprintf( __( 'Comitted %d pages/files to GitHub', 'simply-static-pro' ), $counter );
		$this->save_status_message( $message );
		$this->notify_github();
		$this->notify_external_webhook();

		return true;
	}

	/**
	 * Notify external Webhook after Simply Static finished static export.
	 *
	 * @return void
	 */
	public function notify_external_webhook() {
		$options = get_option( 'simply-static' );

		if ( empty( $options['github-webhook-url'] ) ) {
			return;
		}

		$webhook_args = apply_filters( 'ssp_webhook_args', array() );

		wp_remote_post( esc_url( $options['github-webhook-url'] ), $webhook_args );
	}

	/**
	 * Notify GitHub after Simply Static finished static export.
	 *
	 * @return void
	 */
	public function notify_github() {
		$options = get_option( 'simply-static' );

		if ( $options['delivery_method'] !== 'github' ) {
			return;
		}

		$user = $options['github-user'];
		if ( empty( $user ) ) {
			return;
		}

		$access_token = $options['github-personal-access-token'];
		if ( empty( $access_token ) ) {
			return;
		}

		$repository = $options['github-repository'];
		if ( empty( $repository ) ) {
			return;
		}

		$webhook = 'https://api.github.com/repos/' . $user . '/' . $repository . '/dispatches';

		$webhook_args = array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $access_token,
				'Accept'        => 'application/vnd.github+json',
			),
			'body'    => wp_json_encode(
				array(
					'event_type' => 'repository dispatch'
				)
			)
		);

		wp_remote_post( esc_url( $webhook ), $webhook_args );
	}
}
