<?php

namespace simply_static_pro;

use Github\Client;
use Github\Exception\ValidationFailedException;
use Github\Exception\RuntimeException;
use Github\Exception\ApiLimitExceedException;


/**
 * Class to handle GitHub repositories.
 */
class Github_Repository {
	/**
	 * Contains instance or null
	 *
	 * @var object|null
	 */
	private static $instance = null;

	/**
	 * Contains new GitHub client.
	 *
	 * @var object
	 */
	public $client;

	/**
	 * Contains the user who commits.
	 *
	 * @var array
	 */
	public $committer;

	/**
	 * Contains the username.
	 *
	 * @var string
	 */
	public $user;

	/**
	 * Is an organization account?
	 *
	 * @var string
	 */
	public $is_organization;

	/**
	 * Contains the repository name.
	 *
	 * @var string
	 */
	public $repository;

	/**
	 * Contains the branch name.
	 *
	 * @var string
	 */
	public $branch;

	/**
	 * Contains the visibility of the repository.
	 *
	 * @var string
	 */
	public $visibility;

	/**
	 * Returns instance of Github_Repository.
	 *
	 * @return object
	 */
	public static function get_instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor for repository class.
	 */
	public function __construct() {
		$options = get_option( 'simply-static' );

		if ( ! empty( $options['github-personal-access-token'] ) ) {
			$client = new Client();

			// Authenticate.
			$client->authenticate( $options['github-personal-access-token'], $client::AUTH_ACCESS_TOKEN );

			// Setup data.
			$this->client     = $client;
			$this->user       = $options['github-user'];
			$this->repository = $options['github-repository'];
			$this->branch     = $options['github-branch'];
			$this->visibility = $options['github-repository-visibility'];

			$this->committer = array(
				'name'  => $options['github-user'],
				'email' => $options['github-user']
			);

			// Maybe use organization.
			if ( ! empty( $options['github-is-organization'] ) ) {
				$this->is_organization = $options['github-is-organization'];
			} else {
				$this->is_organization = 'no';
			}
		}
	}

	/**
	 * Add the repository with Ajax.
	 */
	public function ajax_add_repository() {
		// check nonce.
		if ( ! wp_verify_nonce( $_POST['nonce'], 'ssp-add-repository' ) ) {
			$response = array(
				'message' => 'Security check failed.',
				'error'   => true
			);

			print wp_json_encode( $response );
			exit;
		}

		$response = $this->add_repository();

		// Now we can exit Ajax.
		print wp_json_encode( $response );
		exit;
	}

	/**
	 * Add the repository with Ajax.
	 */
	public function add_repository() {
		try {
			if ( 'yes' === $this->is_organization ) {
				$this->client->api( 'repo' )->create( $this->user, $this->repository, __( 'This repository was created with Simply Static Pro', 'simply-static-pro' ), '', true );
			} else {
				$this->client->api( 'repo' )->create( $this->repository, __( 'This repository was created with Simply Static Pro', 'simply-static-pro' ), '', true );
			}

			// Add the sample file.
			$this->add_file( 'simply-static.txt', 'This file was created by Simply Static Pro.', __( 'Added the sample file.', 'simply-static-pro' ) );

			$response = array( 'message' => __( 'Repository was successfully created.', 'simply-static-pro' ) );

			// We should update the options before going further.
			$options = get_option( 'simply-static' );

			// Change repository status.
			$this->change_visibility();

			$options['github-repository-created'] = 'yes';
			update_option( 'simply-static', $options );
		} catch ( ValidationFailedException|RuntimeException|ApiLimitExceedException $e ) {
			$response = array(
				'message' => $e->getMessage(),
				'error'   => true
			);
		}

		return $response;
	}

	/**
	 * Delete the repository with Ajax.
	 */
	public function ajax_delete_repository() {
		// check nonce.
		if ( ! wp_verify_nonce( $_POST['nonce'], 'ssp-delete-repository' ) ) {
			$response = array(
				'message' => 'Security check failed.',
				'error'   => true
			);

			print wp_json_encode( $response );
			exit;
		}

		$response = $this->delete_repository();

		// Now we can exit Ajax.
		print wp_json_encode( $response );
		exit;
	}

	/**
	 * Delete the repository with Ajax.
	 */
	public function delete_repository() {
		// Try to delete repository.
		try {
			$this->client->api( 'repo' )->remove( $this->user, $this->repository );
			$response = array(
				'message' => __( 'Repository was successfully deleted.', 'simply-static-pro' )
			);
		} catch ( ValidationFailedException|RuntimeException|ApiLimitExceedException $e ) {
			$response = array(
				'message' => $e->getMessage(),
				'error'   => true
			);
		}

		// We should reset the options before going further.
		$options = get_option( 'simply-static' );

		$options['github-repository']         = '';
		$options['github-repository-created'] = '';

		update_option( 'simply-static', $options );

		return $response;
	}

	/**
	 * Change visibility of a repository.
	 *
	 * @return string
	 */
	public function change_visibility() {
		if ( 'private' === $this->visibility ) {
			try {
				$this->client->api( 'repo' )->update( $this->user, $this->repository, array( 'private' => true ) );

				return true;
			} catch ( ValidationFailedException|RuntimeException|ApiLimitExceedException $e ) {
				return $e->getMessage();
			}
		} else {
			try {
				$this->client->api( 'repo' )->update( $this->user, $this->repository, array( 'private' => false ) );

				return true;
			} catch ( ValidationFailedException|RuntimeException|ApiLimitExceedException $e ) {
				return $e->getMessage();
			}
		}
	}

	/**
	 * Adding a file to the repository.
	 *
	 * @param string $file_name given file name.
	 * @param string $content content of the file.
	 * @param string $commit_message given commit message.
	 *
	 * @return bool|string
	 */
	public function add_file( string $file_name, string $content, string $commit_message ) {
		try {
			$this->client->api( 'repo' )->contents()->create( $this->user, $this->repository, $file_name, $content, $commit_message, $this->branch, $this->committer );

			return true;
		} catch ( ValidationFailedException|RuntimeException|ApiLimitExceedException $e ) {
			return $e->getMessage();
		}
	}
}
